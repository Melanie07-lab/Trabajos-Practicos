package main;

class Rock implements Jugada {
    @Override
    public boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraRock();
    }

    @Override
    public boolean resultadoContraPaper() {
        return false;
    }

    @Override
    public boolean resultadoContraRock() {
        return false;
    }

    @Override
    public boolean resultadoContraTijeras() {
        return true;
    }

    @Override
    public boolean resultadoContraLizardo() {
        return true;
    }

    @Override
    public boolean resultadoContraSpork() {
        return false;
    }
}
