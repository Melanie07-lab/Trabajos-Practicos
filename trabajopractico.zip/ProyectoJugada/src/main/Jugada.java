package main;

public interface Jugada {
	boolean jugarContra(Jugada otraJugada);
    boolean resultadoContraPaper();
    boolean resultadoContraRock();
    boolean resultadoContraTijeras();
    boolean resultadoContraLizardo();
    boolean resultadoContraSpork();
}
