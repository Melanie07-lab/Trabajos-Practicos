package main;

class Paper implements Jugada {
    @Override
    public boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraPaper();
    }

    @Override
    public boolean resultadoContraPaper() {
        return false;
    }

    @Override
    public boolean resultadoContraRock() {
        return true;
    }

    @Override
    public boolean resultadoContraTijeras() {
        return false;
    }

    @Override
    public boolean resultadoContraLizardo() {
        return false;
    }

    @Override
    public boolean resultadoContraSpork() {
        return true;
    }
}
