package main;

public class Juego {
    public static void main(String[] args) {
        Jugada rock = new Rock();
        Jugada paper = new Paper();
        Jugada tijeras = new Tijeras();
        Jugada lizardo = new Lizardo();
        Jugada spork = new Spork();

        System.out.println("Rock vs Paper: " + rock.jugarContra(paper)); // false
        System.out.println("Paper vs Rock: " + paper.jugarContra(rock)); // true
        System.out.println("Tijeras vs Rock: " + tijeras.jugarContra(rock)); // false
        System.out.println("Lizardo vs Spork: " + lizardo.jugarContra(spork)); // true
        System.out.println("Spork vs Tijeras: " + spork.jugarContra(tijeras)); // true
    }
}
