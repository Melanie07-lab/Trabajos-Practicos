package main;

class Tijeras implements Jugada {
    @Override
    public boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraTijeras();
    }

    @Override
    public boolean resultadoContraPaper() {
        return true;
    }

    @Override
    public boolean resultadoContraRock() {
        return false;
    }

    @Override
    public boolean resultadoContraTijeras() {
        return false;
    }

    @Override
    public boolean resultadoContraLizardo() {
        return true;
    }

    @Override
    public boolean resultadoContraSpork() {
        return false;
    }
}
