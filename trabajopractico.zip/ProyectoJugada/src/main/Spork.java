package main;

class Spork implements Jugada {
    @Override
    public boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraSpork();
    }

    @Override
    public boolean resultadoContraPaper() {
        return false;
    }

    @Override
    public boolean resultadoContraRock() {
        return true;
    }

    @Override
    public boolean resultadoContraTijeras() {
        return true;
    }

    @Override
    public boolean resultadoContraLizardo() {
        return false;
    }

    @Override
    public boolean resultadoContraSpork() {
        return false;
    }
}
