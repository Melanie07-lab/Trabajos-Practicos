package main;

class Lizardo implements Jugada {
    @Override
    public boolean jugarContra(Jugada otraJugada) {
        return !otraJugada.resultadoContraLizardo();
    }

    @Override
    public boolean resultadoContraPaper() {
        return true;
    }

    @Override
    public boolean resultadoContraRock() {
        return false;
    }

    @Override
    public boolean resultadoContraTijeras() {
        return false;
    }

    @Override
    public boolean resultadoContraLizardo() {
        return false;
    }

    @Override
    public boolean resultadoContraSpork() {
        return true;
    }
}
